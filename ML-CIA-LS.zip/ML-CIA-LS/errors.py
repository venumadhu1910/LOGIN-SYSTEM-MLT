from distutils.errors import DistutilsError
class RemovedCommandError(DistutilsError, RuntimeError):
