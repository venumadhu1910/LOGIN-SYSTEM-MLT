from typing import List, Optional
def main(args=None):
    from pip._internal.utils.entrypoints import _wrapper
    return _wrapper(args)
